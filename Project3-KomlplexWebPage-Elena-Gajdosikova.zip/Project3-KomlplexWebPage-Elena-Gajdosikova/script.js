//Responsive Hamburger Menu
const clickBar = document.querySelector(".fa-bars")
const clickCross = document.querySelector(".fa-xmark")
const menu = document.querySelector(".Navbar-Menu")

clickBar.addEventListener("click", () => {
  clickBar.classList.toggle("hide")
  clickCross.classList.toggle("hide")
  menu.classList.toggle("hidden")
})

clickCross.addEventListener("click", () => {
  clickBar.classList.toggle("hide")
  clickCross.classList.toggle("hide")
  menu.classList.toggle("hidden")
})

//Logo Image Change On Click
function changeLogo() {
  const displayImage = document.getElementById("logo")
  if (displayImage.src.match("./images/Handmade.png")) {
    displayImage.src = "./images/GOJlogogreen.png"
  } else {
    displayImage.src = "./images/Handmade.png"
  }
}

//Dark/Light Mode Toggle
document.getElementById("toggle").addEventListener("click", function () {
  document.getElementsByTagName("body")[0].classList.toggle("dark-theme")
})

//Scroll To Top Button
let calcScrollValue = () => {
  let scrollProgress = document.getElementById("progress")
  let progressValue = document.getElementById("progress-value")
  let pos = document.documentElement.scrollTop
  let calcHeight =
    document.documentElement.scrollHeight -
    document.documentElement.clientHeight
  let scrollValue = Math.round((pos * 120) / calcHeight)
  if (pos > 120) {
    scrollProgress.style.display = "grid"
  } else {
    scrollProgress.style.display = "none"
  }
  scrollProgress.addEventListener("click", () => {
    document.documentElement.scrollTop = 0
  })
  scrollProgress.style.background = `conic-gradient(#6fa27c ${scrollValue}%, #d7e8db ${scrollValue}%)`
}
window.onscroll = calcScrollValue
window.onload = calcScrollValue

//Cube 3D slider
let cube = document.querySelector(".image-cube")
let btnNext = document.getElementById("next")
let btnPrev = document.getElementById("prev")
let pos = 0
btnNext.addEventListener("click", () => {
  pos -= 90
  cube.style.transform = `rotateY(${pos}deg)`
})
btnPrev.addEventListener("click", () => {
  pos += 90
  cube.style.transform = `rotateY(${pos}deg)`
})

//Zoom Three images
function zoomImg(x) {
  x.style.height = "390px"
  x.style.width = "310px"
  x.style.transition = "0.9s"
}

function normalImg(x) {
  x.style.height = "350px"
  x.style.width = "270px"
  transition = "0.9s"
}

//Form Confirm Password
function checkPassword() {
  let password = document.getElementById("password").value
  let cnfrmPassword = document.getElementById("cnfrm-password").value
  console.log(" Password:", password, "\n", "Confirm Password:", cnfrmPassword)
  let message = document.getElementById("message")

  if (password.length != 0) {
    if (password == cnfrmPassword) {
      message.textContent = "Passwords match"
      message.style.backgroundColor = "#6fa27c"
      message.style.color = "white"
    } else {
      message.textContent = "Passwords don't match"
      message.style.backgroundColor = "#6fa27c"
      message.style.color = "white"
    }
  } else {
    alert("Password can't be empty!")
    message.textContent = ""
  }
}
